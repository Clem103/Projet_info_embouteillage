To lauch the simulator, simply lauch simulation.py

To see the doc, lauch Doc_index.html