To lauch the simulator, simply lauch main_ihm.py

To see the doc, go in "docs > _build > html" and lauch index.html